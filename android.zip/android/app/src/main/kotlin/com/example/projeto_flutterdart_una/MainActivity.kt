package com.example.projeto_flutterdart_una

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
